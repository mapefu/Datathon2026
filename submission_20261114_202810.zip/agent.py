"""
agent.py — BatteryAgent per al Repte UPC Sostenible (Datathon 2026).

Estratègia: MPC (programació lineal) sobre la finestra de 24 h coneguda + un
estimador de la CÀRREGA NETA de l'hora actual amb Random Forest.

El LP base és el mateix que la versió anterior (validació: 6,10 punts; oráculo
amb informació perfecta: 6,12). El que faltava per igualar l'oràcul és saber
quanta energia pot absorbir la xarxa L'HORA ACTUAL: `obs` només dona el consum i
la solar de l'hora anterior (t-1). El clamp de descàrrega usava net_{t-1} i en
els pocs moments crítics perdia valor. Amb una estimació de net_t (RF entrenat
offline: MAE 34,7 kW a validació contra 167-196 kW dels baselines ingenus) el
clamp es fa amb el valor previst i l'agent iguala l'oràcul a validació (6,12).

Fusió previst/observat, amb criteri físic:
  - La càrrega del campus MAI baixa de ~450 kW: net_{t-1} ~ 0 només pot ser un
    tall de sensor. Dins un tall NO ens fiem del forecast (prediure el rutine)
    EXCEPTE en la finestra de matí (7-9 h), on els talls observats acaben i el
    RF — que mira hora + patró setmanal — anticipa la recuperació.
  - Fora de talls: blend observat/RF amb cap de rampa i <= 500 kW.
  - Les prediccions s'acoten (load 0..4000 kW, pv 0..400 kW) abans d'usar-les.

Models a `modelos_rf.npz` (arbres exportats a arrays numpy: inferència pròpia,
sense dependre de la versió de sklearn del servidor). Les features són EXACTES
les de l'entrenament: lags per timestamp, imputació per mediana amb flags.

Robustesa (no canvia res si les dades són exactes i completes):
  - λ online (quocient CO2/cost viscut) i adaptació a previsions amb error
    (_Previsor), heretades de la versió 6,10 i revalidades aquí.
  - NaN, claus que falten, timestamp string o qualsevol excepció -> regla de
    reserva o 0 kW. Sempre es retalla als límits físics: 0 infraccions.
Capacitat i potencia es llegeixen d'obs (`cap_max_kwh`, `power_max_kw`).

MODE DIFICIL (finestra de mercat curta, <= 8 h): l'agent canvia a un MPC amb LP
de saturacio (variables g, com l'oracul) on el preu, el CO2 i la carga neta de
les +3..+24 h venen de Random Forest entrenats offline (features vectoritzades
identiques a l'entrenament; lags per timestamp exacte; meteo d'obs). Els models
van a `modelos_hard.npz`:

  - preu/CO2 +3..+23 h: MAE 0,0197 EUR/kWh / 0,0163 kg/kWh en val
    (baselines ingenus: 0,028 / 0,017-0,018).
  - load +0..23 h: MAE 91 kW; pv x1: 7,1 kW (s'aplica x12 a l'us).
  - net = load - 12*pv: MAE ~141 kW; deteccio d'excedents (net<0) sensiblement
    millor que persistencia.
  - LP: min sum w_t*g_t s.t. g_t >= net_t + c_t - d_t, g>=0, SOC dins limits,
    c,d <= power_max_kw -> carrega gratuita dels excedents solars i cap
    descarga malgastada quan net < potencia.
"""

import math
import time
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import sparse
from scipy.optimize import linprog

CAP = 2000.0
P_MAX = 500.0
ETA = math.sqrt(0.9)
MARGE = 1e-6  # kW de marge per no tocar mai el límit físic exacte

# λ = (0.30/0.70)·(CO2_base/Cost_base). Prior de train: ≈ 0,59 kg/€.
RATIO_PRIOR = 0.59
PRIOR_COST_EUR = 168 * 1100.0 * 0.138
LAMBDA = 0.30 / 0.70 * RATIO_PRIOR
V_QUANTILE = 0.40

EWMA_ALPHA = 0.02
MIN_OBS_ERR = 24
VAR_EXACTA = 1e-12

TIME_BUDGET_S = 40.0

MODEL_FILE = "modelos_rf.npz"
MODEL_HARD = "modelos_hard.npz"
HARD_WINDOW_MAX = 8      # len(finstreta) <= 8 -> mode dificil
PV_SCALE_HARD = 12.0
K0_HARD = 3              # hores de mercat conegudes al mode dificil


def _f(x, default=float("nan")):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return default
    return v if math.isfinite(v) else default


def _ts_ok(obs):
    """Timestamp com a pd.Timestamp; None si no es pot interpretar."""
    ts = obs.get("timestamp")
    if ts is None:
        return None
    if isinstance(ts, pd.Timestamp):
        return ts
    try:
        return pd.Timestamp(ts)
    except Exception:
        return None


# ------------------------------------------------------------------
# Features (CÒPIA EXACTA de la que genera l'entrenament offline).
# ------------------------------------------------------------------


def _time_features(ts):
    hour, dow, month, doy = ts.hour, ts.dayofweek, ts.month, ts.dayofyear
    return np.array([
        hour / 23.0,
        math.sin(2 * math.pi * hour / 24.0),
        math.cos(2 * math.pi * hour / 24.0),
        dow / 6.0,
        math.sin(2 * math.pi * dow / 7.0),
        math.cos(2 * math.pi * dow / 7.0),
        (month - 1) / 11.0,
        math.sin(2 * math.pi * (doy - 1) / 365.0),
        math.cos(2 * math.pi * (doy - 1) / 365.0),
    ], dtype=np.float64)


class _Hist:
    """Historial indexat per timestamp amb consulta de lags en temps real."""

    def __init__(self):
        self.ts = []
        self.load = []
        self.pv = []
        self.pos = {}

    def add(self, ts, load, pv):
        self.pos[ts] = len(self.ts)
        self.ts.append(ts)
        self.load.append(load)
        self.pv.append(pv)

    def idx(self, ts, hours_back):
        if ts is None:
            return None
        try:
            return self.pos.get(ts - pd.Timedelta(hours=hours_back), None)
        except Exception:
            return None

    def val_lag(self, ts, hours_back, arr):
        i = self.idx(ts, hours_back)
        if i is None:
            return np.nan
        v = arr[i]
        return float(v) if np.isfinite(v) else np.nan

    def same_abs_mean(self, ts, arr, lags):
        vals = []
        for h in lags:
            i = self.idx(ts, h)
            if i is not None and np.isfinite(arr[i]):
                vals.append(arr[i])
        return float(np.mean(vals)) if vals else np.nan


def _nanmean(vals):
    vals = [v for v in vals if np.isfinite(v)]
    return float(np.mean(vals)) if vals else np.nan


N_LOAD = 31
N_PV = 18


def _features_load(hist, ts, preu_t, co2_t, preu_win, co2_win):
    """31 features per predir load_t; només informació anterior a t."""
    load = np.asarray(hist.load, dtype=float)
    pv = np.asarray(hist.pv, dtype=float)

    lag1 = hist.val_lag(ts, 1, load)
    lag24 = hist.val_lag(ts, 24, load)
    lag168 = hist.val_lag(ts, 168, load)
    same3 = _nanmean([hist.val_lag(ts, 24, load),
                      hist.val_lag(ts, 48, load),
                      hist.val_lag(ts, 72, load)])
    same_week6 = hist.same_abs_mean(ts, load, [24 * 7 * k for k in range(1, 7)])
    roll24 = _nanmean(load[max(0, len(load) - 24):]) if len(load) else np.nan

    pw = np.asarray(preu_win, dtype=float)
    cw = np.asarray(co2_win, dtype=float)
    x = np.concatenate([
        _time_features(ts) if ts is not None else np.zeros(9),
        [lag1, lag24,
         hist.val_lag(ts, 48, load), hist.val_lag(ts, 72, load), lag168,
         hist.val_lag(ts, 336, load),
         same3, same_week6, roll24],
        [hist.val_lag(ts, 1, pv), hist.val_lag(ts, 24, pv),
         hist.same_abs_mean(ts, pv, [24 * 7 * k for k in range(1, 7)])],
        [float(preu_t), float(co2_t),
         float(np.nanmean(pw[:3])) if pw.size else np.nan,
         float(np.nanmean(cw[:3])) if cw.size else np.nan,
         float(np.nanmax(pw)) if pw.size else np.nan,
         float(np.nanmax(cw)) if cw.size else np.nan],
        [1.0 if np.isfinite(lag1) else 0.0,
         1.0 if np.isfinite(lag24) else 0.0,
         1.0 if np.isfinite(lag168) else 0.0,
         1.0 if np.isfinite(same_week6) else 0.0],
    ])
    if len(x) != N_LOAD:
        out = np.zeros(N_LOAD)
        out[:min(len(x), N_LOAD)] = x[:N_LOAD]
        return out
    return x


def _features_pv(hist, ts, preu_t):
    """18 features per predir pv_t."""
    pv = np.asarray(hist.pv, dtype=float)
    lag1 = hist.val_lag(ts, 1, pv)
    lag24 = hist.val_lag(ts, 24, pv)
    same_week6 = hist.same_abs_mean(ts, pv, [24 * 7 * k for k in range(1, 7)])
    x = np.concatenate([
        _time_features(ts) if ts is not None else np.zeros(9),
        [lag1, lag24, hist.val_lag(ts, 48, pv), hist.val_lag(ts, 168, pv), same_week6],
        [hist.val_lag(ts, 1, np.asarray(hist.load, dtype=float))],
        [1.0 if np.isfinite(lag1) else 0.0,
         1.0 if np.isfinite(lag24) else 0.0,
         1.0 if np.isfinite(same_week6) else 0.0],
    ])
    if len(x) != N_PV:
        out = np.zeros(N_PV)
        out[:min(len(x), N_PV)] = x[:N_PV]
        return out
    return x


class _Forest:
    """RandomForest exportat a arrays numpy. Inferència pròpia."""

    def __init__(self, z, key):
        self.left = z[key + "_left"]
        self.right = z[key + "_right"]
        self.feat = z[key + "_feat"]
        self.thr = z[key + "_thr"]
        self.val = z[key + "_val"]
        self.med = z[key + "_med"]
        self.roots = np.cumsum(z[key + "_n"]) - z[key + "_n"]

    def predict(self, x):
        if not np.all(np.isfinite(x)):
            x = np.where(np.isnan(x), self.med, x)
        s = 0.0
        left, right, feat, thr, val = self.left, self.right, self.feat, self.thr, self.val
        for root in self.roots:
            i = int(root)
            while left[i] != -1:
                i = int(left[i] if x[feat[i]] <= thr[i] else right[i])
            s += val[i]
        return s / len(self.roots)


def _hist_window(previsor, n):
    """Finestra de fins a 24 valors del previsor per a les features (t..t+23)."""
    h = previsor.hist
    vals = np.asarray(h[n:n + 24], dtype=float)
    if len(vals) < 24:
        pad = np.full(24 - len(vals), vals[-1] if len(vals) else np.nan)
        vals = np.concatenate([vals, pad])
    return vals


# ------------------------------------------------------------------
# Adaptació a previsions amb error (heretada de la versió 6,10).
# ------------------------------------------------------------------


class _Previsor:
    """Per a cada horitzó tria entre la previsió més recent i la combinada
    segons l'error real viscut; amb previsions exactes no canvia res."""

    def __init__(self, n_h=24):
        self.hist = []
        self.pendents = {}
        self.comb_pend = {}
        self.var = np.zeros(n_h + 1)
        self.var_comb = np.zeros(n_h + 1)
        self.n_obs = np.zeros(n_h + 1, dtype=int)
        self.n_comb = np.zeros(n_h + 1, dtype=int)

    @staticmethod
    def _ewma(v, k, e):
        v[k] = (1 - EWMA_ALPHA) * v[k] + EWMA_ALPHA * e * e

    def observa(self, n, actual, previsio):
        if not math.isfinite(actual):
            actual = _f(previsio[0]) if len(previsio) else float("nan")
            if not math.isfinite(actual):
                actual = self.hist[-1] if self.hist else 0.0
        escala = max(abs(actual), 1e-3)
        for k, v in self.pendents.pop(n, []):
            self._ewma(self.var, k, (v - actual) / escala)
            self.n_obs[k] += 1
        for k, v in self.comb_pend.pop(n, []):
            self._ewma(self.var_comb, k, (v - actual) / escala)
            self.n_comb[k] += 1
        self.hist.append(actual)
        for k in range(1, len(previsio)):
            v = previsio[k]
            if math.isfinite(v):
                self.pendents.setdefault(n + k, []).append((k, float(v)))
        return actual

    def finestra(self, n, H):
        out = np.empty(H)
        out[0] = self.hist[n]
        for k in range(1, H):
            cands = self.pendents.get(n + k, [])
            fresca = next((v for kk, v in cands if kk == k), None)
            fiable = self.n_obs[k] >= MIN_OBS_ERR
            if fresca is not None and (not fiable or self.var[k] < VAR_EXACTA):
                out[k] = fresca
                continue
            num = den = 0.0
            for kk, v in cands:
                if self.n_obs[kk] >= MIN_OBS_ERR and self.var[kk] > 0:
                    w = 1.0 / self.var[kk]
                    num += w * v
                    den += w
            comb = num / den if den > 0 else fresca
            if comb is not None:
                self.comb_pend.setdefault(n + k, []).append((k, comb))
            usa_comb = (
                comb is not None
                and self.n_comb[k] >= MIN_OBS_ERR
                and (fresca is None or self.var_comb[k] < self.var[k])
            )
            if usa_comb or fresca is None:
                out[k] = comb if comb is not None else out[k - 1]
            else:
                out[k] = fresca
        return out


# ------------------------------------------------------------------
# MODE DIFICIL: boscos vectoritzats, historial per canals i features.
# ------------------------------------------------------------------


class _FastForest:
    """Batch predict (B files) travessant tots els arbres a la vegada."""

    def __init__(self, z, key):
        self.left = z[key + "_left"]
        self.right = z[key + "_right"]
        self.feat = z[key + "_feat"]
        self.thr = z[key + "_thr"]
        self.val = z[key + "_val"]
        self.med = z[key + "_med"]
        self.roots = (np.cumsum(z[key + "_n"]) - z[key + "_n"]).astype(np.int32)

    def predict_batch(self, X):
        X = np.where(np.isnan(X), self.med[None, :], X)
        XfT = np.ascontiguousarray(np.asarray(X, dtype=np.float64).T)
        B = X.shape[0]
        T = len(self.roots)
        node = np.repeat(self.roots[:, None], B, axis=1)
        active = np.ones((T, B), dtype=bool)
        vals = np.zeros((T, B))
        cols = np.arange(B)
        left, right, feat, thr, val = self.left, self.right, self.feat, self.thr, self.val
        for _ in range(64):
            if not active.any():
                break
            leaf = left[node] == -1
            newly = active & leaf
            if newly.any():
                vals[newly] = val[node[newly]]
                active &= ~leaf
            if not active.any():
                break
            f = feat[node]
            xvals = XfT[f, cols]
            go_left = xvals <= thr[node]
            node = np.where(go_left, left[node], right[node])
        return vals.mean(axis=0)


class _FChannel:
    def __init__(self):
        self.vals = np.zeros(4096)
        self.n = 0
        self.pos = {}

    def append(self, clock, v):
        if self.n >= len(self.vals):
            new = np.zeros(len(self.vals) * 2)
            new[:self.n] = self.vals[:self.n]
            self.vals = new
        self.vals[self.n] = v
        if clock not in self.pos:
            self.pos[clock] = self.n
        self.n += 1

    def gather(self, clocks):
        pos = np.fromiter((self.pos.get(int(c), -1) for c in clocks),
                          dtype=np.int64, count=len(clocks))
        vals = np.full(len(clocks), np.nan)
        ok = pos >= 0
        if ok.any():
            vals[ok] = self.vals[pos[ok]]
        return vals

    def one(self, clock):
        p = self.pos.get(clock, None)
        return self.vals[p] if p is not None else np.nan

    def tail_mean(self, k, before_current):
        end = self.n - (1 if before_current else 0)
        seg = self.vals[max(0, end - k):max(0, end)]
        seg = seg[np.isfinite(seg)]
        return float(seg.mean()) if seg.size > 0 else np.nan


def _fnanmax3(pw):
    fin = np.isfinite(pw)
    return float(np.max(pw[fin])) if fin.any() else np.nan


def _fsame_mean_vec(list_of_gathers):
    stack = np.vstack(list_of_gathers)
    fin = np.isfinite(stack)
    cnt = fin.sum(axis=0)
    s = np.where(fin, stack, 0.0).sum(axis=0)
    out = np.full(stack.shape[1], np.nan)
    m = cnt > 0
    out[m] = s[m] / cnt[m]
    return out


class _FHist:
    """Historial per canals + features vectoritzades (contracte exacte amb
    l'entrenament offline experiments/hard_features.py)."""

    def __init__(self):
        self.load = _FChannel()
        self.pv = _FChannel()
        self.price = _FChannel()
        self.co2 = _FChannel()
        self.irr = _FChannel()
        self.tamb = _FChannel()
        self.tpan = _FChannel()
        self.vent = _FChannel()

    @staticmethod
    def clock(ts):
        return int(pd.Timestamp(ts).timestamp() // 3600)

    def add_market(self, ts, price, co2):
        c = self.clock(ts)
        self.price.append(c, price)
        self.co2.append(c, co2)

    def add_campus(self, clock_prev, load, pv, meteo):
        self.load.append(clock_prev, load)
        self.pv.append(clock_prev, pv)
        self.irr.append(clock_prev, meteo.get("irradiancia_wm2", np.nan))
        self.tamb.append(clock_prev, meteo.get("temp_ambient_c", np.nan))
        self.tpan.append(clock_prev, meteo.get("temp_panel_c", np.nan))
        self.vent.append(clock_prev, meteo.get("vent_ms", np.nan))

    def _base(self, ts, k0, k1):
        H = k1 - k0
        rng = pd.date_range(ts + pd.Timedelta(hours=k0), periods=H, freq="h")
        hour = rng.hour.to_numpy(dtype=float)
        dow = rng.dayofweek.to_numpy(dtype=float)
        month = rng.month.to_numpy(dtype=float)
        doy = rng.dayofyear.to_numpy(dtype=float)
        base9 = np.column_stack([
            hour / 23.0,
            np.sin(2 * np.pi * hour / 24.0),
            np.cos(2 * np.pi * hour / 24.0),
            dow / 6.0,
            np.sin(2 * np.pi * dow / 7.0),
            np.cos(2 * np.pi * dow / 7.0),
            (month - 1) / 11.0,
            np.sin(2 * np.pi * (doy - 1) / 365.0),
            np.cos(2 * np.pi * (doy - 1) / 365.0),
        ])
        kvec = np.arange(k0, k1, dtype=float) / 23.0
        return base9, kvec

    def _clocks(self, cl0, k0, k1):
        return np.arange(cl0 + k0, cl0 + k1, dtype=np.int64)

    def features_price(self, ts, k0, k1, p_win, c_win):
        """Layout v1 EXACT (26 cols), com experiments/hard_features.py."""
        h, H = self, k1 - k0
        base9, kvec = h._base(ts, k0, k1)
        cl0 = h.clock(ts)
        clocks = h._clocks(cl0, k0, k1)
        pw = np.asarray(p_win[:3], dtype=float)
        cw = np.asarray(c_win[:3], dtype=float)
        g25 = h.price.gather(clocks - 25)
        g25c = h.co2.gather(clocks - 25)
        return np.column_stack([
            base9, kvec,
            np.full(H, pw[0] if np.isfinite(pw[0]) else np.nan),
            np.full(H, pw[1] if len(pw) > 1 else np.nan),
            np.full(H, pw[2] if len(pw) > 2 else np.nan),
            np.full(H, h.price.one(cl0 - 1)),
            g25, np.full(H, h.price.tail_mean(24, before_current=True)),
            h.price.gather(clocks - 24),
            h.price.gather(clocks - 48),
            h.price.gather(clocks - 72),
            h.price.gather(clocks - 168),
            h.price.gather(clocks - 336),
            np.full(H, cw[0] if np.isfinite(cw[0]) else np.nan),
            g25c, np.full(H, h.co2.tail_mean(24, before_current=True)),
            np.isfinite(g25).astype(float),
            np.isfinite(g25c).astype(float),
        ])

    def features_co2(self, ts, k0, k1, p_win, c_win):
        """Layout v1 EXACT (24 cols)."""
        h, H = self, k1 - k0
        base9, kvec = h._base(ts, k0, k1)
        cl0 = h.clock(ts)
        clocks = h._clocks(cl0, k0, k1)
        pw = np.asarray(p_win[:3], dtype=float)
        cw = np.asarray(c_win[:3], dtype=float)
        g25c = h.co2.gather(clocks - 25)
        g25p = h.price.gather(clocks - 25)
        return np.column_stack([
            base9, kvec,
            np.full(H, cw[0] if np.isfinite(cw[0]) else np.nan),
            np.full(H, cw[1] if len(cw) > 1 else np.nan),
            np.full(H, cw[2] if len(cw) > 2 else np.nan),
            np.full(H, h.co2.one(cl0 - 1)),
            g25c, np.full(H, h.co2.tail_mean(24, before_current=True)),
            h.co2.gather(clocks - 24),
            h.co2.gather(clocks - 48),
            h.co2.gather(clocks - 72),
            h.co2.gather(clocks - 168),
            h.co2.gather(clocks - 336),
            np.full(H, pw[0] if np.isfinite(pw[0]) else np.nan),
            g25p,
            np.isfinite(g25c).astype(float),
        ])

    def features_load(self, ts, k0, k1, p_win, meteo):
        h, H = self, k1 - k0
        base9, kvec = h._base(ts, k0, k1)
        cl0 = h.clock(ts)
        clocks = h._clocks(cl0, k0, k1)
        irr = _f(meteo.get("irradiancia_wm2"))
        tamb = _f(meteo.get("temp_ambient_c"))
        tpan = _f(meteo.get("temp_panel_c"))
        vent = _f(meteo.get("vent_ms"))
        pw = np.asarray(p_win[:3], dtype=float)
        l1 = h.load.one(cl0 - 1)
        return np.column_stack([
            base9, kvec,
            np.full(H, l1),
            h.load.gather(clocks - 24),
            h.load.gather(clocks - 48),
            h.load.gather(clocks - 72),
            h.load.gather(clocks - 168),
            h.load.gather(clocks - 336),
            np.full(H, h.load.tail_mean(24, before_current=False)),
            np.full(H, irr), np.full(H, tamb), np.full(H, tpan), np.full(H, vent),
            h.pv.gather(clocks - 25),
            np.full(H, h.price.tail_mean(24, before_current=True)),
            np.full(H, _fnanmax3(pw)),
            np.full(H, 1.0 if np.isfinite(l1) else 0.0),
            np.full(H, 1.0 if np.isfinite(irr) else 0.0),
        ])

    def features_pv(self, ts, k0, k1, p_win, meteo):
        h, H = self, k1 - k0
        base9, kvec = h._base(ts, k0, k1)
        base7 = base9[:, :7]
        cl0 = h.clock(ts)
        clocks = h._clocks(cl0, k0, k1)
        irr = _f(meteo.get("irradiancia_wm2"))
        tamb = _f(meteo.get("temp_ambient_c"))
        tpan = _f(meteo.get("temp_panel_c"))
        vent = _f(meteo.get("vent_ms"))
        pv1 = h.pv.one(cl0 - 1)
        return np.column_stack([
            base7, kvec,
            np.full(H, irr),
            h.irr.gather(clocks - 24),
            h.irr.gather(clocks - 48),
            h.irr.gather(clocks - 168),
            np.full(H, h.irr.tail_mean(24, before_current=False)),
            np.full(H, tamb), np.full(H, tpan), np.full(H, vent),
            np.full(H, (tpan - tamb) if (np.isfinite(tpan) and np.isfinite(tamb)) else np.nan),
            np.full(H, pv1),
            h.pv.gather(clocks - 24),
            h.pv.gather(clocks - 168),
            h.load.gather(clocks - 25),
            np.full(H, 1.0 if np.isfinite(irr) else 0.0),
            np.full(H, 1.0 if np.isfinite(pv1) else 0.0),
        ])


# ------------------------------------------------------------------
# Agent
# ------------------------------------------------------------------


class BatteryAgent:
    # Fusió RF/observat per al clamp de net_t (validada a val i a train):
    #   EST_F: fracció del forecast admesa dins un tall, a la finestra de matí;
    #   EST_G/EST_RAMP: blend i cap de rampa fora dels talls;
    #   EST_M0/EST_M1: finestra de matí on el RF pot autoritzar la descàrrega.
    EST_F = 0.75
    EST_G = 0.5
    EST_RAMP = 150.0
    EST_M0, EST_M1 = 7, 9

    # Mode dificil
    HD_HORIZON = 24       # horitzo del LP-hard
    HD_VQ = 0.40          # quantil del valor terminal
    HD_SURPLUS = "full"   # full | damp | pos (excedents solars)
    HD_EST0 = "blend"     # rf | rf_pure | prev | blend | max (fusio frada 0)
    HD_D0_TRUST = 1.0
    HD_TIME_BUDGET = 40.0
    HD_REPLAN = 2         # replanifica cada N hores (executa el pla entremig)
    HD_FRESH_K = 12       # horitzons frescos per pas; buffer per als altres
    HD_LP_METHOD = "highs"
    HD_EXT_REPEAT = True  # (inert amb H=24)

    def __init__(self, v_quantile: float = V_QUANTILE):
        self.v_quantile = v_quantile
        self._lp_cache = {}
        self._t_total = 0.0
        self.n = 0
        self.preu = _Previsor()
        self.co2 = _Previsor()
        self.s_co2 = 0.0
        self.s_cost = 0.0
        self.hist = _Hist()
        self.prev_ts = None
        self.rf = None
        try:
            z = np.load(Path(__file__).parent / MODEL_FILE)
            self.rf = (_Forest(z, "rf_l"), _Forest(z, "rf_p"))
        except Exception:
            self.rf = None
        # mode dificil
        self.h = _FHist()
        self.h_n = 0
        self.h_prev_clock = None
        self.h_rf = None
        self._lp_hard_cache = {}
        self._t_hard_lp = 0.0
        self._t_hard_rf = 0.0
        self._h_buf = None
        self._h_buf_net = None
        self._h_plan = None
        self._h_plan_n0 = -1
        try:
            zh = np.load(Path(__file__).parent / MODEL_HARD)
            self.h_rf = {k: _FastForest(zh, k) for k in ("price", "co2", "load", "pv")}
        except Exception:
            self.h_rf = None

    # -------------------- LP --------------------
    def _lp(self, H):
        if H not in self._lp_cache:
            I = sparse.identity(H, format="csr")
            D = I - sparse.eye(H, k=-1, format="csr")
            self._lp_cache[H] = sparse.hstack([-ETA * I, I / ETA, D], format="csr")
        return self._lp_cache[H]

    def _lambda(self):
        ratio = (RATIO_PRIOR * PRIOR_COST_EUR + self.s_co2) / (PRIOR_COST_EUR + self.s_cost)
        return 0.30 / 0.70 * ratio

    # -------------------- estimació de net_t --------------------
    def _est_net0(self, n, hora, net_prev, ts):
        """Estimació de la càrrega neta de l'hora ACTUAL (kW)."""
        prev = max(net_prev, 0.0)
        if prev >= 500.0:
            return 500.0  # clamp no vinculant: mantenim l'observat
        rf = None
        if self.rf is not None and ts is not None and self.preu.hist:
            try:
                pw = _hist_window(self.preu, n)
                cw = _hist_window(self.co2, n)
                xl = _features_load(self.hist, ts, self.preu.hist[n], self.co2.hist[n], pw, cw)
                xp = _features_pv(self.hist, ts, self.preu.hist[n])
                load_hat = float(self.rf[0].predict(xl))
                pv_hat = float(self.rf[1].predict(xp))
                load_hat = min(max(load_hat, 0.0), 4000.0)
                pv_hat = min(max(pv_hat, 0.0), 400.0)
                rf = max(0.0, load_hat - pv_hat)
            except Exception:
                rf = None
        if rf is None:
            return min(500.0, prev)
        if prev < 50.0:
            # anomalia física (la càrrega mai baixa de ~450 kW) = tall en curs
            if self.EST_M0 <= hora <= self.EST_M1:
                return max(prev, min(500.0, self.EST_F * rf))
            return prev
        return max(prev, min(500.0, self.EST_G * (prev + rf), prev + self.EST_RAMP))

    # -------------------- cicle --------------------
    def act(self, obs: dict) -> float:
        Lk = len(obs.get("preus_properes_24h") or []) if isinstance(obs, dict) else 0
        cap_obs = _f(obs.get("cap_max_kwh"), CAP) if isinstance(obs, dict) else CAP
        pmax_obs = _f(obs.get("power_max_kw"), P_MAX) if isinstance(obs, dict) else P_MAX
        soc = _f(obs.get("soc_kwh") if isinstance(obs, dict) else None, 0.0)
        soc = min(max(soc, 0.0), max(cap_obs, 1.0))
        # mode dificil: finestra de mercat curta (i bateria gran)
        if (0 < Lk <= HARD_WINDOW_MAX and self.h_rf is not None) or \
                (cap_obs > CAP + 1.0 and Lk > 0 and self.h_rf is not None):
            try:
                p = self._decideix_hard(obs, soc, cap_obs, pmax_obs)
            except Exception:
                p = 0.0
        else:
            try:
                p = self._decideix(obs, soc)
            except Exception:
                p = 0.0
        p = _f(p, 0.0)
        max_c = max(0.0, min(pmax_obs, (cap_obs - soc) / ETA - MARGE))
        max_d = max(0.0, min(pmax_obs, soc * ETA - MARGE))
        p = max(-max_d, min(max_c, p))
        return 0.0 if abs(p) < 1e-3 else float(p)

    def _decideix_hard(self, obs, soc, cap, pmax):
        # `n` es l'index del pas en curs; el comptador s'incrementa SEMPRE al
        # principi (el replan usa la paritat absoluta, mai la relativa)
        n = self.h_n
        self.h_n += 1
        ts = _ts_ok(obs)
        pw = [_f(x) for x in (obs.get("preus_properes_24h") or [])]
        cw = [_f(x) for x in (obs.get("co2_properes_24h") or [])]
        Lk = len(pw)

        dades = obs.get("noves_dades_5min") or {}
        load_prev = _f(dades.get("ultim_consum_kw"), np.nan)
        pv_prev12 = _f(dades.get("ultima_solar_kw"), np.nan)
        meteo = {k: _f(dades.get(k, np.nan)) for k in
                 ("irradiancia_wm2", "temp_ambient_c", "temp_panel_c", "vent_ms")}
        net_prev = (load_prev if math.isfinite(load_prev) else np.nan) - \
                   (pv_prev12 if math.isfinite(pv_prev12) else 0.0)
        p0 = pw[0] if Lk and math.isfinite(pw[0]) else np.nan
        c0 = cw[0] if Lk and math.isfinite(cw[0]) else np.nan

        # historial sempre (barat); el plan previ cobreix els passos no-replan
        h = self.h
        cp = None
        if ts is not None:
            h.add_market(ts, p0, c0)
            cp = h.clock(ts)
            if self.h_prev_clock is not None and math.isfinite(load_prev):
                h.add_campus(self.h_prev_clock, load_prev,
                             pv_prev12 / PV_SCALE_HARD if math.isfinite(pv_prev12) else np.nan,
                             meteo)
        self.h_prev_clock = cp

        replan = (self.HD_REPLAN <= 1) or (n % self.HD_REPLAN == 0)
        if not replan and self._h_plan is not None and self._h_plan_n0 >= 0:
            m = n - self._h_plan_n0
            c_seq, d_seq = self._h_plan
            if 0 <= m < len(c_seq):
                max_c = max(0.0, min(pmax, (cap - soc) / ETA - MARGE))
                max_d = max(0.0, min(pmax, soc * ETA - MARGE))
                p = max(-max_d, min(max_c, float(c_seq[m] - d_seq[m])))
                return p if abs(p) >= 1e-3 else 0.0
            self._h_plan_n0 = -1

        # lambda online
        if n >= 1 and math.isfinite(net_prev) and cp is not None:
            net = max(net_prev, 0.0)
            p1 = h.price.one(cp - 1)
            c1 = h.co2.one(cp - 1)
            if not math.isfinite(p1):
                p1 = p0 if math.isfinite(p0) else 0.12
            if not math.isfinite(c1):
                c1 = c0 if math.isfinite(c0) else 0.10
            self.s_co2 += net * c1
            self.s_cost += net * p1
        lam = self._lambda()

        H = self.HD_HORIZON
        w = np.empty(H)
        for k in range(min(Lk, H)):
            w[k] = (cw[k] if math.isfinite(cw[k]) else 0.10) + \
                   lam * (pw[k] if math.isfinite(pw[k]) else 0.12)

        # preu/co2: fresc K0..K0+fresh-1; buffer (pas previ, index j -> target
        # (t-1)+K0+j) per als altres horitzons
        t0 = time.perf_counter()
        fresh = max(0, min(self.HD_FRESH_K, H - K0_HARD))
        prf = cof = None
        try:
            if fresh > 0 and ts is not None:
                Xp = h.features_price(ts, K0_HARD, K0_HARD + fresh, pw, cw)
                Xc = h.features_co2(ts, K0_HARD, K0_HARD + fresh, pw, cw)
                prf = np.clip(self.h_rf["price"].predict_batch(Xp), 0.005, 0.6)
                cof = np.clip(self.h_rf["co2"].predict_batch(Xc), 0.0, 0.5)
        except Exception:
            prf = cof = None
        if prf is None:
            fresh = 0
        buf_pr, buf_co = self._h_buf if self._h_buf is not None else (None, None)
        pr_far = np.empty(H - K0_HARD)
        co_far = np.empty(H - K0_HARD)
        for j in range(H - K0_HARD):
            k = K0_HARD + j
            if k < K0_HARD + fresh or buf_pr is None:
                jj = min(max(k - K0_HARD, 0), (len(prf) - 1 if prf is not None else 0))
                if prf is not None:
                    pr_far[j] = prf[jj]
                    co_far[j] = cof[jj]
                else:
                    pr_far[j] = 0.12
                    co_far[j] = 0.10
            else:
                jj = k + 1 - K0_HARD
                if 0 <= jj < len(buf_pr):
                    pr_far[j] = buf_pr[jj]
                    co_far[j] = buf_co[jj]
                else:
                    pr_far[j] = buf_pr[-1]
                    co_far[j] = buf_co[-1]
        self._h_buf = (pr_far, co_far)
        self._t_hard_rf += time.perf_counter() - t0
        for k in range(K0_HARD, H):
            w[k] = co_far[k - K0_HARD] + lam * pr_far[k - K0_HARD]

        # net forecast: fresc 0..fresh-1; buffer (index j = target (t-1)+j)
        t0 = time.perf_counter()
        nfresh = max(1, min(self.HD_FRESH_K, H))
        est_net = np.empty(H)
        fresh_part = None
        try:
            if ts is not None:
                xl = h.features_load(ts, 0, nfresh, pw, meteo)
                xv = h.features_pv(ts, 0, nfresh, pw, meteo)
                load_hat = np.clip(self.h_rf["load"].predict_batch(xl), 0.0, 5000.0)
                pv_hat = np.clip(self.h_rf["pv"].predict_batch(xv), 0.0, 400.0)
                fresh_part = load_hat - PV_SCALE_HARD * pv_hat
        except Exception:
            fresh_part = None
        if fresh_part is None:
            cl0 = h.clock(ts) if ts is not None else 0
            l24 = h.load.gather(np.arange(cl0 - 24, cl0 + nfresh - 24))
            v24 = h.pv.gather(np.arange(cl0 - 24, cl0 + nfresh - 24)) * PV_SCALE_HARD
            fresh_part = np.where(np.isfinite(l24), l24, 1000.0) - \
                np.where(np.isfinite(v24), v24, 0.0)
        for k in range(H):
            if k < nfresh:
                est_net[k] = fresh_part[min(k, len(fresh_part) - 1)]
            elif self._h_buf_net is not None:
                jj = k + 1
                est_net[k] = self._h_buf_net[jj] if jj < len(self._h_buf_net) \
                    else self._h_buf_net[-1]
            else:
                est_net[k] = fresh_part[-1]
        self._h_buf_net = est_net.copy()
        self._t_hard_rf += time.perf_counter() - t0

        if self.HD_SURPLUS == "full":
            est_use = est_net
        elif self.HD_SURPLUS == "damp":
            est_use = np.where(est_net >= 0, est_net, est_net * 0.7)
        else:
            est_use = np.maximum(est_net, 0.0)
        est_use = np.clip(est_use, -3000.0, 3000.0)

        if self.HD_EST0 == "prev":
            net0 = max(net_prev, 0.0) if math.isfinite(net_prev) else est_use[0]
        elif self.HD_EST0 == "rf_pure":
            net0 = est_use[0]
        elif self.HD_EST0 == "blend":
            a = est_use[0]
            b = max(net_prev, 0.0) if math.isfinite(net_prev) else a
            net0 = max(0.0, min(a, b + 250.0))
        elif self.HD_EST0 == "max":
            net0 = max(est_use[0], 0.0)
            if math.isfinite(net_prev) and net_prev >= 0:
                net0 = max(net0, min(pmax, net_prev))
        else:  # rf
            net0 = est_use[0]
            if math.isfinite(net_prev) and net_prev >= 0:
                net0 = max(net0, self.HD_D0_TRUST * min(pmax, net_prev))
        net_h = np.empty(H)
        net_h[0] = net0
        net_h[1:] = est_use[1:]

        # valor terminal (la finestra: si < 3 h, l'episod acaba aviat -> v=0)
        if Lk >= 3:
            v = float(np.quantile(w, self.HD_VQ))
        else:
            v = 0.0

        # LP g-form: min sum w*g - v*s_end
        p = None
        if self._t_hard_lp >= self.HD_TIME_BUDGET:
            return self._hd_fallback(w, net_h, pmax)
        t0 = time.perf_counter()
        try:
            A_eq, Aub = self._lp_hard(H)
            cost = np.concatenate([np.zeros(2 * H), np.zeros(H), w])
            # regularitzacio minuscula: trenca la degeneracio de c/d
            # (les diferencies reals de w son >> eps)
            cost[:2 * H] += 1e-6
            cost[2 * H + H - 1] -= v
            b_eq = np.zeros(H)
            b_eq[0] = soc
            b_ub = -net_h
            g_ub = np.maximum(net_h, 0.0) + pmax
            bounds = ([(0.0, pmax)] * (2 * H) + [(0.0, cap)] * H +
                      [(0.0, float(g)) for g in g_ub])
            sol = linprog(cost, A_ub=Aub, b_ub=b_ub, A_eq=A_eq, b_eq=b_eq,
                          bounds=bounds, method=self.HD_LP_METHOD)
            self._t_hard_lp += time.perf_counter() - t0
            if sol.success:
                x = sol.x
                p = float(x[0] - x[H])
                if self.HD_REPLAN > 1:
                    self._h_plan = (x[:H].copy(), x[H:2 * H].copy())
                    self._h_plan_n0 = self.h_n - 1
        except Exception:
            self._t_hard_lp += time.perf_counter() - t0
        if p is None:
            return self._hd_fallback(w, net_h, pmax)
        return p

    def _hd_fallback(self, w, net_h, pmax):
        rank = float(np.mean(w <= w[0]))
        d0 = min(pmax, max(0.0, net_h[0]))
        return pmax if rank <= 0.25 else (-d0 if rank >= 0.75 else 0.0)

    def _lp_hard(self, H):
        if H not in self._lp_hard_cache:
            I = sparse.identity(H, format="csr")
            D = I - sparse.eye(H, k=-1, format="csr")
            Z = sparse.csr_matrix((H, H))
            A_eq = sparse.hstack([-ETA * I, I / ETA, D, Z], format="csr")
            Aub = sparse.hstack([I, -I, Z, -I], format="csr")
            self._lp_hard_cache[H] = (A_eq, Aub)
        return self._lp_hard_cache[H]

    def _decideix(self, obs, soc):
        n = self.n
        self.n += 1
        ts = _ts_ok(obs)
        hour = int(_f(obs.get("hour"), ts.hour if ts is not None else 0))

        prev_p = np.array([_f(x) for x in (obs.get("preus_properes_24h") or [])], dtype=float)
        prev_c = np.array([_f(x) for x in (obs.get("co2_properes_24h") or [])], dtype=float)

        # càrrega neta de l'hora anterior -> lambda online + historial
        dades = obs.get("noves_dades_5min") or {}
        load_prev = _f(dades.get("ultim_consum_kw"), np.nan)
        pv_prev = _f(dades.get("ultima_solar_kw"), np.nan)
        net_prev = (load_prev if math.isfinite(load_prev) else 1e9) - \
                   (pv_prev if math.isfinite(pv_prev) else 0.0)
        if n >= 1 and net_prev < 1e8:
            net = max(net_prev, 0.0)
            self.s_co2 += net * self.co2.hist[n - 1]
            self.s_cost += net * self.preu.hist[n - 1]
            # registra el consum observat sota el timestamp de l'obs anterior
            self.hist.add(self.prev_ts if self.prev_ts is not None else ts,
                          load_prev if math.isfinite(load_prev) else 0.0,
                          pv_prev if math.isfinite(pv_prev) else 0.0)
        self.prev_ts = ts

        # si la finestra no comença a l'hora actual, l'alineem (en la simulació
        # oficial p[0] == preu_actual i això no canvia res).
        p_raw = _f(obs.get("preu_actual"))
        c_raw = _f(obs.get("co2_actual"))
        if (len(prev_p) and math.isfinite(prev_p[0]) and math.isfinite(p_raw)
                and abs(prev_p[0] - p_raw) > 1e-9):
            al_p = np.concatenate([[p_raw], prev_p])[:24]
            al_c = np.concatenate([[c_raw], prev_c])[:24]
        else:
            al_p, al_c = prev_p, prev_c
        H = int(min(len(al_p), len(al_c)))

        self.preu.observa(n, p_raw, al_p[:H])
        self.co2.observa(n, c_raw, al_c[:H])
        if H == 0:
            return 0.0

        preus = self.preu.finestra(n, H)
        co2 = self.co2.finestra(n, H)
        w = co2 + self._lambda() * preus

        # Finestra incompleta -> l'avaluació acaba dins l'horitzó:
        # l'energia final no val res.
        v = float(np.quantile(w, self.v_quantile)) if H >= 24 else 0.0

        # ---- clamp de descàrrega de l'hora 0 amb l'estimació de net_t ----
        est0 = self._est_net0(n, hour, net_prev if net_prev < 1e8 else 1500.0, ts)
        d0_max = min(P_MAX, max(0.0, est0))

        p = None
        if self._t_total < TIME_BUDGET_S:
            t0 = time.perf_counter()
            cost = np.concatenate([w, -w, np.zeros(H)])
            cost[-1] -= v
            b_eq = np.zeros(H)
            b_eq[0] = soc
            bounds = [(0.0, P_MAX)] * (2 * H) + [(0.0, CAP)] * H
            bounds[H] = (0.0, d0_max)
            sol = linprog(cost, A_eq=self._lp(H), b_eq=b_eq, bounds=bounds, method="highs")
            self._t_total += time.perf_counter() - t0
            if sol.success:
                p = float(sol.x[0] - sol.x[H])
        if p is None:  # regla de reserva
            rank = float(np.mean(w <= w[0]))
            p = P_MAX if rank <= 0.25 else (-d0_max if rank >= 0.75 else 0.0)
        return p
